import 'dart:async';

import 'index.dart';
import 'serializers.dart';
import 'package:built_value/built_value.dart';

part 'spservicesdetails_record.g.dart';

abstract class SpservicesdetailsRecord
    implements Built<SpservicesdetailsRecord, SpservicesdetailsRecordBuilder> {
  static Serializer<SpservicesdetailsRecord> get serializer =>
      _$spservicesdetailsRecordSerializer;

  String? get name;

  String? get servicetype;

  String? get servicecharge;

  String? get phonenumber;

  String? get mobilenumber;

  String? get email;

  String? get address;

  @BuiltValueField(wireName: kDocumentReferenceField)
  DocumentReference? get ffRef;
  DocumentReference get reference => ffRef!;

  static void _initializeBuilder(SpservicesdetailsRecordBuilder builder) =>
      builder
        ..name = ''
        ..servicetype = ''
        ..servicecharge = ''
        ..phonenumber = ''
        ..mobilenumber = ''
        ..email = ''
        ..address = '';

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('spservicesdetails');

  static Stream<SpservicesdetailsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map(
          (s) => serializers.deserializeWith(serializer, serializedData(s))!);

  static Future<SpservicesdetailsRecord> getDocumentOnce(
          DocumentReference ref) =>
      ref.get().then(
          (s) => serializers.deserializeWith(serializer, serializedData(s))!);

  SpservicesdetailsRecord._();
  factory SpservicesdetailsRecord(
          [void Function(SpservicesdetailsRecordBuilder) updates]) =
      _$SpservicesdetailsRecord;

  static SpservicesdetailsRecord getDocumentFromData(
          Map<String, dynamic> data, DocumentReference reference) =>
      serializers.deserializeWith(serializer,
          {...mapFromFirestore(data), kDocumentReferenceField: reference})!;
}

Map<String, dynamic> createSpservicesdetailsRecordData({
  String? name,
  String? servicetype,
  String? servicecharge,
  String? phonenumber,
  String? mobilenumber,
  String? email,
  String? address,
}) {
  final firestoreData = serializers.toFirestore(
    SpservicesdetailsRecord.serializer,
    SpservicesdetailsRecord(
      (s) => s
        ..name = name
        ..servicetype = servicetype
        ..servicecharge = servicecharge
        ..phonenumber = phonenumber
        ..mobilenumber = mobilenumber
        ..email = email
        ..address = address,
    ),
  );

  return firestoreData;
}

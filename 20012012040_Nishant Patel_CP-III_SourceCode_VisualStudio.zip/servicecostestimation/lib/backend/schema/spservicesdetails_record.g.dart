// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'spservicesdetails_record.dart';

// **************************************************************************
// BuiltValueGenerator
// **************************************************************************

Serializer<SpservicesdetailsRecord> _$spservicesdetailsRecordSerializer =
    new _$SpservicesdetailsRecordSerializer();

class _$SpservicesdetailsRecordSerializer
    implements StructuredSerializer<SpservicesdetailsRecord> {
  @override
  final Iterable<Type> types = const [
    SpservicesdetailsRecord,
    _$SpservicesdetailsRecord
  ];
  @override
  final String wireName = 'SpservicesdetailsRecord';

  @override
  Iterable<Object?> serialize(
      Serializers serializers, SpservicesdetailsRecord object,
      {FullType specifiedType = FullType.unspecified}) {
    final result = <Object?>[];
    Object? value;
    value = object.name;
    if (value != null) {
      result
        ..add('name')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.servicetype;
    if (value != null) {
      result
        ..add('servicetype')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.servicecharge;
    if (value != null) {
      result
        ..add('servicecharge')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.phonenumber;
    if (value != null) {
      result
        ..add('phonenumber')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.mobilenumber;
    if (value != null) {
      result
        ..add('mobilenumber')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.email;
    if (value != null) {
      result
        ..add('email')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.address;
    if (value != null) {
      result
        ..add('address')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(String)));
    }
    value = object.ffRef;
    if (value != null) {
      result
        ..add('Document__Reference__Field')
        ..add(serializers.serialize(value,
            specifiedType: const FullType(
                DocumentReference, const [const FullType.nullable(Object)])));
    }
    return result;
  }

  @override
  SpservicesdetailsRecord deserialize(
      Serializers serializers, Iterable<Object?> serialized,
      {FullType specifiedType = FullType.unspecified}) {
    final result = new SpservicesdetailsRecordBuilder();

    final iterator = serialized.iterator;
    while (iterator.moveNext()) {
      final key = iterator.current! as String;
      iterator.moveNext();
      final Object? value = iterator.current;
      switch (key) {
        case 'name':
          result.name = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String?;
          break;
        case 'servicetype':
          result.servicetype = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String?;
          break;
        case 'servicecharge':
          result.servicecharge = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String?;
          break;
        case 'phonenumber':
          result.phonenumber = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String?;
          break;
        case 'mobilenumber':
          result.mobilenumber = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String?;
          break;
        case 'email':
          result.email = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String?;
          break;
        case 'address':
          result.address = serializers.deserialize(value,
              specifiedType: const FullType(String)) as String?;
          break;
        case 'Document__Reference__Field':
          result.ffRef = serializers.deserialize(value,
              specifiedType: const FullType(DocumentReference, const [
                const FullType.nullable(Object)
              ])) as DocumentReference<Object?>?;
          break;
      }
    }

    return result.build();
  }
}

class _$SpservicesdetailsRecord extends SpservicesdetailsRecord {
  @override
  final String? name;
  @override
  final String? servicetype;
  @override
  final String? servicecharge;
  @override
  final String? phonenumber;
  @override
  final String? mobilenumber;
  @override
  final String? email;
  @override
  final String? address;
  @override
  final DocumentReference<Object?>? ffRef;

  factory _$SpservicesdetailsRecord(
          [void Function(SpservicesdetailsRecordBuilder)? updates]) =>
      (new SpservicesdetailsRecordBuilder()..update(updates))._build();

  _$SpservicesdetailsRecord._(
      {this.name,
      this.servicetype,
      this.servicecharge,
      this.phonenumber,
      this.mobilenumber,
      this.email,
      this.address,
      this.ffRef})
      : super._();

  @override
  SpservicesdetailsRecord rebuild(
          void Function(SpservicesdetailsRecordBuilder) updates) =>
      (toBuilder()..update(updates)).build();

  @override
  SpservicesdetailsRecordBuilder toBuilder() =>
      new SpservicesdetailsRecordBuilder()..replace(this);

  @override
  bool operator ==(Object other) {
    if (identical(other, this)) return true;
    return other is SpservicesdetailsRecord &&
        name == other.name &&
        servicetype == other.servicetype &&
        servicecharge == other.servicecharge &&
        phonenumber == other.phonenumber &&
        mobilenumber == other.mobilenumber &&
        email == other.email &&
        address == other.address &&
        ffRef == other.ffRef;
  }

  @override
  int get hashCode {
    return $jf($jc(
        $jc(
            $jc(
                $jc(
                    $jc(
                        $jc($jc($jc(0, name.hashCode), servicetype.hashCode),
                            servicecharge.hashCode),
                        phonenumber.hashCode),
                    mobilenumber.hashCode),
                email.hashCode),
            address.hashCode),
        ffRef.hashCode));
  }

  @override
  String toString() {
    return (newBuiltValueToStringHelper(r'SpservicesdetailsRecord')
          ..add('name', name)
          ..add('servicetype', servicetype)
          ..add('servicecharge', servicecharge)
          ..add('phonenumber', phonenumber)
          ..add('mobilenumber', mobilenumber)
          ..add('email', email)
          ..add('address', address)
          ..add('ffRef', ffRef))
        .toString();
  }
}

class SpservicesdetailsRecordBuilder
    implements
        Builder<SpservicesdetailsRecord, SpservicesdetailsRecordBuilder> {
  _$SpservicesdetailsRecord? _$v;

  String? _name;
  String? get name => _$this._name;
  set name(String? name) => _$this._name = name;

  String? _servicetype;
  String? get servicetype => _$this._servicetype;
  set servicetype(String? servicetype) => _$this._servicetype = servicetype;

  String? _servicecharge;
  String? get servicecharge => _$this._servicecharge;
  set servicecharge(String? servicecharge) =>
      _$this._servicecharge = servicecharge;

  String? _phonenumber;
  String? get phonenumber => _$this._phonenumber;
  set phonenumber(String? phonenumber) => _$this._phonenumber = phonenumber;

  String? _mobilenumber;
  String? get mobilenumber => _$this._mobilenumber;
  set mobilenumber(String? mobilenumber) => _$this._mobilenumber = mobilenumber;

  String? _email;
  String? get email => _$this._email;
  set email(String? email) => _$this._email = email;

  String? _address;
  String? get address => _$this._address;
  set address(String? address) => _$this._address = address;

  DocumentReference<Object?>? _ffRef;
  DocumentReference<Object?>? get ffRef => _$this._ffRef;
  set ffRef(DocumentReference<Object?>? ffRef) => _$this._ffRef = ffRef;

  SpservicesdetailsRecordBuilder() {
    SpservicesdetailsRecord._initializeBuilder(this);
  }

  SpservicesdetailsRecordBuilder get _$this {
    final $v = _$v;
    if ($v != null) {
      _name = $v.name;
      _servicetype = $v.servicetype;
      _servicecharge = $v.servicecharge;
      _phonenumber = $v.phonenumber;
      _mobilenumber = $v.mobilenumber;
      _email = $v.email;
      _address = $v.address;
      _ffRef = $v.ffRef;
      _$v = null;
    }
    return this;
  }

  @override
  void replace(SpservicesdetailsRecord other) {
    ArgumentError.checkNotNull(other, 'other');
    _$v = other as _$SpservicesdetailsRecord;
  }

  @override
  void update(void Function(SpservicesdetailsRecordBuilder)? updates) {
    if (updates != null) updates(this);
  }

  @override
  SpservicesdetailsRecord build() => _build();

  _$SpservicesdetailsRecord _build() {
    final _$result = _$v ??
        new _$SpservicesdetailsRecord._(
            name: name,
            servicetype: servicetype,
            servicecharge: servicecharge,
            phonenumber: phonenumber,
            mobilenumber: mobilenumber,
            email: email,
            address: address,
            ffRef: ffRef);
    replace(_$result);
    return _$result;
  }
}

// ignore_for_file: always_put_control_body_on_new_line,always_specify_types,annotate_overrides,avoid_annotating_with_dynamic,avoid_as,avoid_catches_without_on_clauses,avoid_returning_this,deprecated_member_use_from_same_package,lines_longer_than_80_chars,no_leading_underscores_for_local_identifiers,omit_local_variable_types,prefer_expression_function_bodies,sort_constructors_first,test_types_in_equals,unnecessary_const,unnecessary_new,unnecessary_lambdas
